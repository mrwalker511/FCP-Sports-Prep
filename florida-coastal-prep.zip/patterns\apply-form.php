<?php
/**
 * Title: Admissions Application Portal
 * Slug: fl-coastal-prep/apply-form
 * Categories: featured, text
 */
?>
<!-- wp:group {"style":{"spacing":{"padding":{"top":"6rem","bottom":"6rem"}},"color":{"background":"var(--wp--preset--color--base)"}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group has-background"
    style="background-color:var(--wp--preset--color--base);padding-top:6rem;padding-bottom:6rem">

    <!-- wp:group {"style":{"spacing":{"margin":{"bottom":"4rem"}}}} -->
    <div class="wp-block-group" style="margin-bottom:4rem">
        <!-- wp:paragraph {"style":{"typography":{"fontSize":"0.625rem","fontWeight":"700","letterSpacing":"0.3em","textTransform":"uppercase"}},"textColor":"primary"} -->
        <p class="has-primary-color has-text-color"
            style="font-size:0.625rem;font-weight:700;letter-spacing:0.3em;text-transform:uppercase">Step 1 of 3</p>
        <!-- /wp:paragraph -->
        <!-- wp:heading {"level":2,"style":{"typography":{"fontSize":"3rem","fontStyle":"italic"}},"textColor":"secondary","fontFamily":"display"} -->
        <h2 class="wp-block-heading has-secondary-color has-text-color has-display-font-family"
            style="font-size:3rem;font-style:italic;text-transform:uppercase">Personal Profile</h2>
        <!-- /wp:heading -->
        <!-- wp:group {"style":{"color":{"background":"var(--wp--preset--color--primary)"}},"layout":{"selfStretch":"fixed","flexSize":"4px"}} -->
        <div class="wp-block-group has-background"
            style="background-color:var(--wp--preset--color--primary);height:4px;width:33%"></div>
        <!-- /wp:group -->
    </div>
    <!-- /wp:group -->

    <!-- wp:paragraph {"style":{"typography":{"fontSize":"1.25rem","fontStyle":"italic"}},"textColor":"base","className":"opacity-60"} -->
    <p class="has-base-color has-text-color opacity-60" style="font-size:1.25rem;font-style:italic">Please use the form
        below to start your application. For security and complex logic, we recommend integrating this with a plugin
        like <strong>WPForms</strong> or <strong>Contact Form 7</strong>.</p>
    <!-- /wp:paragraph -->

    <!-- wp:group {"style":{"spacing":{"padding":{"top":"2rem","right":"2rem","bottom":"2rem","left":"2rem"}},"border":{"width":"1px","style":"solid","color":"rgba(17,34,64,0.05)"}},"backgroundColor":"base"} -->
    <div class="wp-block-group has-base-background-color has-background"
        style="border-color:rgba(17,34,64,0.05);border-style:solid;border-width:1px;padding-top:2rem;padding-right:2rem;padding-bottom:2rem;padding-left:2rem">
        <!-- wp:paragraph {"align":"center"} -->
        <p class="has-text-align-center">[FORM PLACEHOLDER: Insert WPForms or Contact Form 7 Shortcode Here]</p>
        <!-- /wp:paragraph -->
    </div>
    <!-- /wp:group -->

</div>
<!-- /wp:group -->