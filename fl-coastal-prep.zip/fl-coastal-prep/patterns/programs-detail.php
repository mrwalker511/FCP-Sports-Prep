<?php
/**
 * Title: Programs Detail Section
 * Slug: fl-coastal-prep/programs-detail
 * Categories: featured, text
 * Viewport Width: 1400
 * Block Types: core/group, core/columns, core/column, core/image, core/heading, core/paragraph
 * Description: Detailed program information with alternating image/text layout.
 */
?>
<!-- wp:group {"className":"section-spacing-large","layout":{"type":"constrained"}} -->
<div class="wp-block-group section-spacing-large">

    <!-- wp:columns {"align":"wide","style":{"spacing":{"blockGap":{"top":"4rem","left":"4rem"},"margin":{"bottom":"10rem"}}}} -->
    <div class="wp-block-columns alignwide" style="margin-bottom:10rem">
        <!-- wp:column {"width":"50%"} -->
        <div class="wp-block-column" style="flex-basis:50%">
            <!-- wp:image {"sizeSlug":"large","linkDestination":"none","className":"program-image"} -->
            <figure class="wp-block-image size-large program-image">
                <img src="assets/images/placeholder-athletic-track.webp"
                    alt="Athletes in a professional track and field training session" />
            </figure>
            <!-- /wp:image -->
        </div>
        <!-- /wp:column -->

        <!-- wp:column {"width":"50%"} -->
        <div class="wp-block-column" style="flex-basis:50%">
            <!-- wp:paragraph {"className":"text-label-small letter-spacing-normal","textColor":"primary"} -->
            <p class="has-primary-color has-text-color text-label-small letter-spacing-normal">Athletic Track
            </p>
            <!-- /wp:paragraph -->

            <!-- wp:heading {"level":2,"className":"text-blueprint-h2","textColor":"base","fontFamily":"display"} -->
            <h2 class="wp-block-heading has-base-color has-text-color has-display-font-family text-blueprint-h2">
                The Pro-Informed Methodology</h2>
            <!-- /wp:heading -->

            <!-- wp:paragraph {"style":{"typography":{"fontSize":"1.125rem","lineHeight":"1.75","fontStyle":"italic"}},"textColor":"base","className":"opacity-60"} -->
            <p class="has-base-color has-text-color opacity-60"
                style="font-size:1.125rem;font-style:italic;line-height:1.75">Our basketball program isn't just
                training; it's a 24-month roadmap to the D1 level. We integrate NBA-style video analysis, personalized
                strength metrics, and high-intensity tactical drills.</p>
            <!-- /wp:paragraph -->

            <!-- wp:list {"className":"is-style-no-disc"} -->
            <ul class="is-style-no-disc">
                <!-- wp:list-item -->
                <li><span class="has-primary-color">―</span> BIOMETRIC TRACKING</li>
                <!-- /wp:list-item -->
                <!-- wp:list-item -->
                <li><span class="has-primary-color">―</span> NBA-STYLE VIDEO ROOM</li>
                <!-- /wp:list-item -->
                <!-- wp:list-item -->
                <li><span class="has-primary-color">―</span> D1 SCOUTING NETWORK</li>
                <!-- /wp:list-item -->
            </ul>
            <!-- /wp:list -->

            <!-- wp:buttons -->
            <div class="wp-block-buttons">
                <!-- wp:button {"backgroundColor":"secondary","textColor":"base","className":"is-style-small","style":{"typography":{"fontSize":"0.625rem","fontWeight":"700","letterSpacing":"0.2em","textTransform":"uppercase"}}} -->
                <div class="wp-block-button is-style-small"><a href="/contact"
                        class="wp-block-button__link has-base-color has-secondary-background-color has-text-color has-background wp-element-button"
                        style="font-size:0.625rem;font-weight:700;letter-spacing:0.2em;text-transform:uppercase">Download
                        Brochure</a></div>
                <!-- /wp:button -->
            </div>
            <!-- /wp:buttons -->
        </div>
        <!-- /wp:column -->
    </div>
    <!-- /wp:columns -->

    <!-- wp:columns {"align":"wide","style":{"spacing":{"blockGap":{"top":"4rem","left":"4rem"}}}} -->
    <div class="wp-block-columns alignwide">
        <!-- wp:column {"width":"50%"} -->
        <div class="wp-block-column" style="flex-basis:50%">
            <!-- wp:paragraph {"className":"text-label-small letter-spacing-normal","textColor":"primary"} -->
            <p class="has-primary-color has-text-color text-label-small letter-spacing-normal">Academic Track
            </p>
            <!-- /wp:paragraph -->

            <!-- wp:heading {"level":2,"className":"text-blueprint-h2","textColor":"base","fontFamily":"display"} -->
            <h2 class="wp-block-heading has-base-color has-text-color has-display-font-family text-blueprint-h2">
                University Preparatory Core</h2>
            <!-- /wp:heading -->

            <!-- wp:paragraph {"style":{"typography":{"fontSize":"1.125rem","lineHeight":"1.75","fontStyle":"italic"}},"textColor":"base","className":"opacity-60"} -->
            <p class="has-base-color has-text-color opacity-60"
                style="font-size:1.125rem;font-style:italic;line-height:1.75">We prioritize intellectual growth with a
                STEM-heavy curriculum. Small class sizes ensure our student-athletes exceed standard NCAA eligibility
                requirements and excel in university environments.</p>
            <!-- /wp:paragraph -->

            <!-- wp:list {"className":"is-style-no-disc"} -->
            <ul class="is-style-no-disc">
                <!-- wp:list-item -->
                <li><span class="has-primary-color">―</span> SAT/ACT MASTERY</li>
                <!-- /wp:list-item -->
                <!-- wp:list-item -->
                <li><span class="has-primary-color">―</span> 1-ON-1 TUTORING</li>
                <!-- /wp:list-item -->
                <!-- wp:list-item -->
                <li><span class="has-primary-color">―</span> NCAA COMPLIANCE LAB</li>
                <!-- /wp:list-item -->
            </ul>
            <!-- /wp:list -->

            <!-- wp:buttons -->
            <div class="wp-block-buttons">
                <!-- wp:button {"backgroundColor":"secondary","textColor":"base","className":"is-style-small","style":{"typography":{"fontSize":"0.625rem","fontWeight":"700","letterSpacing":"0.2em","textTransform":"uppercase"}}} -->
                <div class="wp-block-button is-style-small"><a href="/contact"
                        class="wp-block-button__link has-base-color has-secondary-background-color has-text-color has-background wp-element-button"
                        style="font-size:0.625rem;font-weight:700;letter-spacing:0.2em;text-transform:uppercase">Download
                        Brochure</a></div>
                <!-- /wp:button -->
            </div>
            <!-- /wp:buttons -->
        </div>
        <!-- /wp:column -->

        <!-- wp:column {"width":"50%"} -->
        <div class="wp-block-column" style="flex-basis:50%">
            <!-- wp:image {"sizeSlug":"large","linkDestination":"none","className":"program-image"} -->
            <figure class="wp-block-image size-large program-image">
                <img src="assets/images/placeholder-academic-study.webp"
                    alt="Students studying in the university preparatory academic wing" />
            </figure>
            <!-- /wp:image -->
        </div>
        <!-- /wp:column -->
    </div>
    <!-- /wp:columns -->

</div>
<!-- /wp:group -->